const express = require("express");
const router = express.Router();
const orgController = require("../controller/orgController");

router.get("/getorgbyid/:id", orgController.getOrgById)
router.post("/addorg", orgController.addOrg);
router.post("/login", orgController.login);

module.exports = router;