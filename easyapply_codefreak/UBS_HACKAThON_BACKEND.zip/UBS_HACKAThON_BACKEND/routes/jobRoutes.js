const express = require("express");
const router = express.Router();
const jobController = require("../controller/jobController");
const auth = require("../middleware/auth");

router.get("/getalljobsbyid", auth, jobController.getalljobsbyid);
router.get("/getjobbyid/:id", auth, jobController.getJobById);
router.get("/getrecommnededusers/:id", auth, jobController.getRecomendedUser);
router.post("/addjobs", auth, jobController.addJobs);

module.exports = router;
