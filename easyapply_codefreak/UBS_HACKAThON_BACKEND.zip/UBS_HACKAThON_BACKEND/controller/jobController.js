const jdModel = require("../model/JobdescriptionModel");
const userModel = require("../model/userModel");
const nodemailer = require("nodemailer");

async function mailSender(subject, toAddress, uname, body) {
  // connect with the smtp
  let transporter = await nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 587,
    auth: {
      user: "visaverakesh20@gmail.com",
      pass: "prmwoskqrbbmofte",
    },
  });

  let info = await transporter.sendMail({
    from: "visaverakesh20@gmail.com", // sender address
    to: toAddress, // list of receivers
    subject: subject, // Subject line
    text: "", // plain text body
    html: `<!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=
        , initial-scale=1.0">
        <title>Email </title>
      </head>
      <style>
        .div1{
        display: block;
        margin-left: auto;
        margin-right: auto;
        width: 50%;
        border: 1px solid #ddd;
        border-radius: 4px;
        padding: 5px;
        height: 250px;
        width: 550px;
        }
        .im1{
        display: block;
        margin-left: auto;
        margin-right: auto;
        width: 50%;
        border: 1px solid #ddd;
        border-radius: 4px;
        padding: 5px;
        height: 250px;
        width: 550px;
        }
        .container{
        display: block;
        margin-left: auto;
        margin-right: auto;
        width: 50%;
        border: 1px solid #ddd;
        border-radius: 4px;
        padding: 5px;
        height: 250px;
        width: 550px;
        }
        .p{
          text-align: center;
          font-style:normal;
          font-family: 'Times New Roman', Times, serif;
          margin-left: 15px;
          margin-right: auto;
          padding: 5px;
          margin-left: 15px;
        }
        .container2{
        display: block;
        margin-left: auto;
        margin-right: auto;
        align-items: center;
        width: 50%;
        border: 1px solid #ddd;
        border-radius: 4px;  
       padding-left: 10px;
        height: 50px;
        width: 550px;
        display: flex;
      
        
        float: center;
        }
        .image{
        display: block;
        align-items: center;
        margin-left: 105px ;
        margin-right: 15px;
        width: 20%;
        border: 1px solid #ddd;
        border-radius: 4px;
        padding: 5px;
        height: 30px;
        width: 30px;
        float: left;
        }
        .container3{
        display: block;
        margin-left: auto;
        margin-right: auto;
        width: 50%;
        border: 1px solid #ddd;
        border-radius: 4px;
        padding: 5px;
        height: 50px;
        width: 550px;
        }
        .p1{
        display: block;
        margin-left: auto;
        margin-right: auto;
        text-align: center;
        font-style:normal;
        font-family: 'Times New Roman', Times, serif;
        margin-left: 15px;
        margin-right: auto;
        padding: 5px;
       
        }
        
      </style>
      <body>
        <div class="div1">  
        <img class="im1" src="https://res.cloudinary.com/dq1yel2fk/image/upload/v1676688386/logo_o91syq.jpg" alt="image not loaded">
          
        </div>
        <div class="container">
          <p>20 Feb, 2023</p>
      
          <p>Dear ${uname}</p>
      
      <p>${body}</p>
      
        </div>
        
        <div class="container3">
          <p class="p1">Thank You And Best Regards For Future</p>
        </div>
      </body>
      </html>`, // html body
  });

  // console.log("Message sent: %s", info.messageId);
  // res.json(info);
}

exports.addJobs = async (req, res) => {
  try {
    const {
      company,
      oid,
      job_name,
      job_desc,
      job_role,
      job_skills,
      job_experience,
      education,
      location,
    } = req.body;

    const result = await jdModel.create({
      company,
      oid,
      job_name,
      job_desc,
      job_role,
      job_skills,
      job_experience,
      education,
      location,
    });

    // if result not null send mail to user and recruiter
    if (result != null) {
      const orgEmail = req.user.email;

      //  convert skills to lower case
      let skillSet = result.job_skills;
      const jdSkills = [];
      for (let i = 0; i < skillSet.length; i++) {
        jdSkills[i] = skillSet[i].toLowerCase().trim();
      }

      const user = await userModel.find();
      // traverse for every user and run the algorithm
      user.map((res) => {
        const userSkills = res.skill;
        for (let i = 0; i < userSkills.length; i++) {
          userSkills[i] = userSkills[i].toLowerCase().trim();
        }
        let count = 0;
        for (let i = 0; i < userSkills.length; i++) {
          if (jdSkills.includes(userSkills[i])) {
            count++;
          }
        }
        // match percentile
        const match = (count / jdSkills.length) * 100;
        console.log(res.u_name + " " + match);

        if (match >= 40) {
          // send email to org and user
          const userEmail = res.u_email;
          const userName = res.u_name;

          // send mail to user
          const j_name = result.job_name;
          console.log(j_name);
          const userBody = `Your profile match some of the jobs on portal. You might have some great opportunities waiting for you`
          mailSender(
            "New Job Openings matching your profile",
            userEmail,
            userName,
            userBody
          );

          const hrBody = `Some new user's found with skill set matching the job you posted`;
          // send mail to organization
          mailSender("Check out matching job profiles", orgEmail, orgEmail, hrBody);
        }
      });

      return res
        .status(200)
        .json({ success: true, message: "Data saved successully", result });
    } else {
      return res
        .status(400)
        .json({ success: false, message: "Data not saved error occured" });
    }
  } catch (e) {
    console.log(e.message);
    return res.status(500).json({ message: "Some error occured" });
  }
};

exports.getalljobsbyid = async (req, res) => {
  try {
    const id = req.user._id.toString();
    console.log(id);
    const result = await jdModel.find({ oid: id });
    if (result != null) {
      return res.status(200).json({ success: true, data: result });
    } else {
      return res.status(400).json({ success: false, data: null });
    }
  } catch (e) {
    console.log(e.message);
    return res.status(500).json({ message: "Some error occured" });
  }
};

exports.getJobById = async (req, res) => {
  try {
    const id = req.params.id;
    const result = await jdModel.findOne({ _id: id });
    if (result != null) {
      return res.status(200).json({ success: true, data: result });
    } else {
      return res.status(400).json({ success: false, data: null });
    }
  } catch (e) {
    console.log(e);
    return res.status(500).json({ message: "Some error occured" });
  }
};

exports.getRecomendedUser = async (req, res) => {
  try {
    const jid = req.params.id;
    const job = await jdModel.findOne({ _id: jid });

    //  convert skills to lower case
    let skillSet = job.job_skills;
    const jdSkills = [];
    for (let i = 0; i < skillSet.length; i++) {
      jdSkills[i] = skillSet[i].toLowerCase().trim();
    }

    const user = await userModel.find();
    let finalUser = [];
    // traverse for every user and run the algorithm
    user.map((res) => {
      const userSkills = res.skill;
      for (let i = 0; i < userSkills.length; i++) {
        userSkills[i] = userSkills[i].toLowerCase().trim();
      }
      let count = 0;
      for (let i = 0; i < userSkills.length; i++) {
        if (jdSkills.includes(userSkills[i])) {
          count++;
        }
      }
      // match percentile
      const match = (count / jdSkills.length) * 100;
      console.log(res.u_name + " " + match);
      if (match >= 40) {
        finalUser.push({ data: res, match: match });
      }
      // console.log(job.job_name);
    });
    return res.status(200).json({ job_name: job.job_name, user: finalUser });
  } catch (e) {
    console.log(e.message);
    return res.status(500).json({ message: "Some error occured" });
  }
};
