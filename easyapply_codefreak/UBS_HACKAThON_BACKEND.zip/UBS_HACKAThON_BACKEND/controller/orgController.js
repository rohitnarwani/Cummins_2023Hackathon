const jwt = require("jsonwebtoken");
const orgModel = require("../model/orgModel");

exports.addOrg = async (req, res) => {
  try {
    const { org_name, email, password, image_url } = req.body;
    const result = await orgModel.create({
      org_name,
      email,
      password,
      image_url,
    });

    if (result != null) {
      return res
        .status(200)
        .json({ success: true, message: "Data saved successfully" });
    } else {
      return res
        .status(400)
        .json({ success: false, message: "Data not saved successfully" });
    }
  } catch (e) {
    console.log(e.message);
    return res.status(500).json({ message: "Some error occured" });
  }
};

exports.getOrgById = async (req, res) => {
  try {
    const id = req.params.id;
    const result = await orgModel.findOne({ _id: id });
    if (result != null) {
      return res.status(200).json({ success: true, data: result });
    } else {
      return res.status(400).json({ success: false, data: null });
    }
  } catch (e) {
    console.log(e.message);
    return res.status(500).json({ message: "Some error occured" });
  }
};

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const result = await orgModel.findOne({ email, password });

    if (result) {
      const uid = result._id.toString();
      const token = jwt.sign({ uid }, "easyapply", { expiresIn: "1d" });
      return res.status(200).json({ success: true, company: result.org_name, token: `Bearer ${token}`, uid: uid });
    } else {
      return res.status(200).json({
        success: false,
        message: `Please check your username or password`,
      });
    }
  } catch (e) {
    console.log(e.message);
    return res.status(500).json({ message: "Some error occured" });
  }
};
