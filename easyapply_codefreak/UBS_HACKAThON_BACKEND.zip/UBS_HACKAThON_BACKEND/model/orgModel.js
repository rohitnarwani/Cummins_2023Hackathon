const mongoose = require("mongoose");

const orgModel = mongoose.Schema({
    org_name: {
        type: String,
        require: true,
    },
    email: {
        type: String, 
        require: true,
    },
    password: {
        type: String,
        require: true,
    },
    image_url: {
        type: String, 
        default: ""
    }
});

module.exports = new mongoose.model("orgModel", orgModel);