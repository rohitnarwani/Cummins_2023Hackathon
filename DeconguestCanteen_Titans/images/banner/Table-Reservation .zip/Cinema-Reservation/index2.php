$link = mysqli_connect("localhost:3307", "root", "", "cinema_db");

// Query to get the movie info and the number of booked seats for each movie
$sql = "SELECT movietable.*, IFNULL(SUM(bookingtable.numTickets), 0) AS bookedSeats FROM movietable LEFT JOIN bookingtable ON movietable.movieID = bookingtable.movieID GROUP BY movietable.movieID";

?>
<!-- <header></header> -->
<div id="home-section-1" class="movie-show-container">
    <h1>Currently Showing</h1>
    <h3>Book a movie now</h3>

    <div class="movies-container">

        <?php
            if($result = mysqli_query($link, $sql)){
                if(mysqli_num_rows($result) > 0){
                    while($row = mysqli_fetch_array($result)){
                        $availableSeats = $row['numSeats'] - $row['bookedSeats'];
                        echo '<div class="movie-box">';
                        echo '<img src="'. $row['movieImg'] .'" alt=" ">';
                        echo '<div class="movie-info ">';
                        echo '<h3>'. $row['movieTitle'] .'</h3>';
                        echo '<h2>'. $availableSeats .' seats available</h2>';
                        echo '<a href="booking.php?id='.$row['movieID'].'"><i class="fas fa-ticket-alt"></i> Book a seat</a>';
                        echo '</div>';
                        echo '</div>';
                    }
                    mysqli_free_result($result);
                } else{
                    echo '<h4 class="no-annot">No Booking to our movies right now</h4>';
                }
            } else{
                echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
            }

            // Close connection
            mysqli_close($link);
        ?>
    </div>
</div>
